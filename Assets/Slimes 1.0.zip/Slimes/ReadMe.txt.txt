# Slime Invasion - Animated Enemy Pack

**Format:** 32x32 px | **Includes animations** | Perfect for platformers, RPGs, and action games

---

## 🎮 About the Pack

Bring your levels to life with a set of versatile, fully animated slime enemies!  
**Slime Invasion** is perfect for indie developers who want to add charm and challenge to their 2D games.

---

## 📦 What's Included

- 4 base Slimes (Green, Blue, Gold, Red)
- 1 King Slime Boss with 10 animations
- Organized folders by slime color and animation type
- **.aseprite** source files included
- **.json** files with animation data
- Commercial and personal use license

---

## ✨ Base Slime Animations

Each base slime includes:

- **Idle** animation
- **Movement:**
  - Walk 1
  - Walk 2
  - Jump
- **Attack:**
  - Attack 1
  - Attack 2
- **Reactions:**
  - DMG (hit reaction)
  - Death (death animation)

---

## 👑 King Slime Boss Animations

The King Slime comes with unique boss animations:

- Idle
- Walk
- Rotate
- Front Attack
- Laser Attack
- Back Attack
- Spine Attack
- DMG (hit reaction)
- Death
- Roar

---

## 🛠️ Perfect for:

- Platformers
- RPGs
- Action games
- Game prototypes
- Engines like Unity, Godot, RPG Maker, and more!

---

## 💬 Feedback & Suggestions

If you enjoyed this asset pack, I would love to hear your feedback!

Feel free to suggest:

- New types of slimes you'd like to see (elemental slimes, armored slimes, flying slimes, etc.)
- New boss slime ideas (mechanical slimes, themed bosses, multi-phase fights...)

Leave a comment or send a message — your ideas could shape the next updates for **Slime Invasion**!

---

## 📜 License

- Free to use for both **commercial** and **personal** projects.
- No attribution required (but highly appreciated!).

---

Thank you for checking out **Slime Invasion**!  
Happy developing! 👾🎨
